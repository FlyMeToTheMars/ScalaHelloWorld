create definer = root@`%` event event_truncate_history_data on schedule
  every '1' MONTH
    starts '2019-07-01 00:01:00'
    ends '2019-12-01 00:01:00'
  on completion preserve
  enable
  do
  CALL process_truncate_history_data(1);

