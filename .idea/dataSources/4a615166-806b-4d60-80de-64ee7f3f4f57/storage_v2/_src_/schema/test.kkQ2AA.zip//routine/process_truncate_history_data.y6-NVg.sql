create procedure process_truncate_history_data(IN truncate_history_data tinyint)
BEGIN
	#Routine body goes here...
  declare this_month VARCHAR(50) default '';
  declare today VARCHAR(10) default '';
  select day(NOW()) as tmp into today from dual;
 if today = '27' then 
 # select case when MONTH(NOW())<10 then CONCAT('day_alarm_summary_0',MONTH(NOW())) else CONCAT('day_alarm_summary_',MONTH(NOW())) end as tmp into this_month from dual;
 # set @trunSql = concat('TRUNCATE table ',this_month);
 # PREPARE temp from @trunSql;
 # execute temp;

  select case when MONTH(NOW())<10 then CONCAT('foreign_day_run_summary_0',MONTH(NOW())) else CONCAT('foreign_day_run_summary_',MONTH(NOW())) end as tmp into this_month from dual;
  set @trunSql = concat('TRUNCATE table ',this_month);
  PREPARE temp from @trunSql;
  execute temp;

 # select case when MONTH(NOW())<10 then CONCAT('day_alarm_summary_0',MONTH(NOW())) else CONCAT('day_alarm_summary_',MONTH(NOW())) end as tmp into this_month from dual;
 # set @trunSql = concat('TRUNCATE table ',this_month);
 # PREPARE temp from @trunSql;
 # execute temp;

 # select case when MONTH(NOW())<10 then CONCAT('day_distance_summary_0',MONTH(NOW())) else CONCAT('day_distance_summary_',MONTH(NOW())) end as tmp into this_month from dual;
 # set @trunSql = concat('TRUNCATE table ',this_month);
 # PREPARE temp from @trunSql;
 # execute temp;
end if;

END;

